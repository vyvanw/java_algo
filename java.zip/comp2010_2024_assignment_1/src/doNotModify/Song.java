package doNotModify;

public class Song {  // DO NOT MODIFY THIS CLASS
    public String title;
    public String artist;

    public Song(String t, String a) {
        title = t;
        artist = a;
    }
    
}
